Student name: Ashley Labelle	  
Student number: 8597896
Course code: ITI 1121 A  

Student name: Tair Nuriev	  
Student number: 8728406  
Course code: ITI 1121 A
 
This archive contains the 5 files of the assignment 1, that is, this file (README.txt), the file A1Q1.java, A1Q2.java, A1Q3.java, A1Q4.java, ArrayStringsTools.java, and StudentInfo.java.