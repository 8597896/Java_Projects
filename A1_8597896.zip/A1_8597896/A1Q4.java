import java.util.Scanner;
import java.util.Random;
/**
 * The class <b>A1Q4</b> is an implementation of the
 * ``Old Maid'' card game, based on the Python implementation
 * given in ITI1020
 *
 * @author gvj (gvj@eecs.uottawa.ca)
 *
 */

public class A1Q4{

 /**
 * Array used to store the full deck of cards,
 */
 private static String[] deck;

 /**
 * The current number of cards in the full deck of cards
 */
 private static int sizeDeck;

 /**
 * Array used to store the player's deck of cards
 */
 private static String[] playerDeck;

 /**
 * The current number of cards in the player's deck of cards
 */
 private static int sizePlayerDeck;

 /**
 * Array used to store the computer's deck of cards
 */
 private static String[] computerDeck;

 /**
 * The current number of cards in the computer's deck of cards
 */
 private static int sizeComputerDeck;


 /**
 * An instance of java.util.Scanner, which will get input from the
 * standard input
 */
  private static Scanner sc;

 /**
 * An instance of java.util.Random, to generate random numbers
 */
  private static Random generator;

 /** 
     * Constructor of the class. Creates the full deck of cards
     */
 
  public  A1Q4(){
  
  sc = new Scanner(System.in);
  generator = new Random();

  String[] suits = {"\u2660", "\u2661", "\u2662", "\u2663"};
  String[] ranks = {"2","3","4","5","6","7","8","9","10","J","Q","K","A"};
  sizeDeck = suits.length*ranks.length - 1;
  deck = new String[sizeDeck];
  int index = 0;
  for(int i =0 ; i < ranks.length; i++){
   for(int j =0 ; j < suits.length; j++){
    if(!(ranks[i]=="Q" && suits[j]=="\u2663")){
     deck[index++]= ranks[i] + " of " + suits[j];
    }
   }
  }
 }

 /** 
     * Waits for user input
     */
 private static void waitForUserInput(){
  sc.nextLine();
 }

 /**
 *  Deals the cards, taking sizeDeck cards out of deck, and deals them
 *  into playerDeck and computerDeck, starting with playerDeck
 */
 private static void dealCards(){
   playerDeck = new String[51];
   computerDeck = new String[51];
   for(int i=0;i<sizeDeck;i++) {
     if(i%2==0) {
       if(sizePlayerDeck == 0) {
         sizePlayerDeck = appendItem(playerDeck,0,deck[i]);
       } else {
         sizePlayerDeck = appendItem(playerDeck,sizePlayerDeck,deck[i]);
       }
     } else {
       if(sizeComputerDeck == 0) {
         sizeComputerDeck = appendItem(computerDeck,0,deck[i]);
       } else {
         sizeComputerDeck = appendItem(computerDeck,sizeComputerDeck,deck[i]);
       }
     }
   }
 }

 /**
 *  Removes all the pairs of cards from the array deckOfCards, that currently
 * contains currentSize cards. deckOfCards is unsorted. It should also not
 * be sorted once the method terminates. 
 *
    *   @param deckOfCards the array of Strings representing the deck of cards
    *   @param currentSize the number of strings in the deckOfCards
,
    *   stored from deckOfCards
[0] to deckOfCards
[currentSize-1]
    *   @return the number of cards in deckOfCards once the pair are removed
    */
 private static int removePairs(String[] deckOfCards, int currentSize){
   sortArray(deckOfCards, currentSize);
   String dup = new String("");
   for(int j =0;j<3;j++) {
     for(int i = 0; i<currentSize-1;i++) {
         if(dup == deckOfCards[i].substring(0,1)) {
           currentSize = removeItemByIndex(deckOfCards,currentSize,i);
           continue;
       }
       if(deckOfCards[i+1].contains(deckOfCards[i].substring(0,1))) {
         dup = deckOfCards[i].substring(0,1);
         currentSize = removeItemByIndex(deckOfCards,currentSize,i);  
         currentSize = removeItemByIndex(deckOfCards,currentSize,i);
       }
     }
   }
   shuffleArray(deckOfCards,currentSize);
   return currentSize;
 }
 /**
 *  Get a valid index of a card to be removed from computerDeck.
 * Note: this method does not check that the input is indeed an integer and
 * will crash if something else is provided.
 *  @return the valid input.
 */
 private static int getValidInput(){
   Scanner userInput = new Scanner(System.in);
   System.out.print("Give me an integer between 1 and "+sizeComputerDeck+": ");
   int i = userInput.nextInt();
   while (i<1 || i>sizeComputerDeck){
     System.out.println("Invalid number. Please enter integer between 1 and "+sizeComputerDeck+": ");
     i = userInput.nextInt();
   }
   return i; 
 }
 
 
 


 /**
 *  The actual game, as per the Python implementation
 */
 public static void playGame(){
  java.util.Random generator = new java.util.Random();
  for(int i = sizeDeck-1 ; i > 1 ; i--){
   swapItems(deck, i,generator.nextInt(i-1));
  }
  
  dealCards();
  
  System.out.println("Hello. My name is Robot and I am the dealer.");
  System.out.println("Welcome to my card game!");
  System.out.println("Your current deck of cards is:");
  
  printArray(playerDeck,sizePlayerDeck);  
  
  System.out.println("Do not worry. I cannot see the order of your cards");
  System.out.println("");
  System.out.println("Now discard all the pairs from your deck. I will do the same.");
  
  sizePlayerDeck = removePairs(playerDeck,sizePlayerDeck);
  sizeComputerDeck = removePairs(computerDeck,sizeComputerDeck);
  
  while (sizeComputerDeck != 0 && sizePlayerDeck != 0){
    
    System.out.println("***********************************************************");
    System.out.println("Your turn.\n");
    System.out.println("Your current deck of cards is:\n");
    
    printArray(playerDeck,sizePlayerDeck);
    
    System.out.println("I have "+sizeComputerDeck+" cards. If 1 stands for my first card and");
    System.out.println(sizeComputerDeck+" for my last card, which of my cards would you like?");
    
    int playerChoice = getValidInput();
    
    if (playerChoice%10==1){
      System.out.println("You asked for my "+playerChoice+"st card");
     } else if (playerChoice%10==2){
       System.out.println("You asked for my "+playerChoice+"nd card");
     } else if (playerChoice%10==3){
       System.out.println("You asked for my "+playerChoice+"rd card");
     } else if (playerChoice>10 && playerChoice<20){
       System.out.println("You asked for my "+playerChoice+"th card");
     } else {
       System.out.println("You asked for my "+playerChoice+"th card");
     }
     
     System.out.println("Here it is. It is "+computerDeck[playerChoice-1]);
     System.out.println("With "+computerDeck[playerChoice-1]+"added, your current deck of cards is:");
     
     printArray(playerDeck,sizePlayerDeck);
     
     int choice = playerChoice-1;
     
     sizePlayerDeck = appendItem(playerDeck, sizePlayerDeck, computerDeck[playerChoice-1]);
     sizeComputerDeck = removeItemByIndex(computerDeck, sizeComputerDeck, choice);
     
     if (sizePlayerDeck==0){
       System.out.println("Ups. You do not have any more cards");
       System.out.println("Congratulations! You, Human, win");
       break;
         }
     
     System.out.println("And after discarding pairs and shuffling, your deck is: ");

    sizePlayerDeck = removePairs(playerDeck,sizePlayerDeck);
    sizeComputerDeck = removePairs(computerDeck,sizeComputerDeck);
    printArray(playerDeck,sizePlayerDeck);

    System.out.println("\nPress enter to continue.");
    waitForUserInput();

    if (sizeComputerDeck==0){
      System.out.println("Ups. I do not have any more cards");
      System.out.println("You lost! I, Robot, win");
     break;
   }
   
   System.out.println("***********************************************************");
   System.out.println("My turn.");
   
   int b = generator.nextInt(sizePlayerDeck);
   int computerChoice = b;
  
  // computerChoice = 0;
   if ((computerChoice+1)%10==1){
     System.out.println("I took your "+(computerChoice+1)+"st card");
   } else if ((computerChoice+1)%10==2){
     System.out.println("I took your "+(computerChoice+1)+"nd card");
   } else if ((computerChoice+1)%10==3){
     System.out.println("I took your "+(computerChoice+1)+"rd card");
   } else if ((computerChoice+1)>10 &&(computerChoice+1)<20){
      System.out.println("I took your "+(computerChoice+1)+"th card");
   } else {
      System.out.println("I took your "+(computerChoice+1)+"th card");
   }
     sizeComputerDeck = appendItem(computerDeck, sizeComputerDeck, playerDeck[computerChoice]);
     sizePlayerDeck = removeItemByIndex(playerDeck, sizePlayerDeck, computerChoice);
     sizePlayerDeck = removePairs(playerDeck,sizePlayerDeck);
     sizeComputerDeck = removePairs(computerDeck,sizeComputerDeck);
     
     System.out.println("\nPress enter to continue.");
     waitForUserInput();

     if (sizePlayerDeck==0){
       System.out.println("Ups. You do not have any more cards");
       System.out.println("Congratulations! You, Human, win");
       break;
         }
         else if (sizeComputerDeck==0){
         System.out.println("Ups. I do not have any more cards");
         System.out.println("You lost! I, Robot, win");
         break;
         }

    }

 }

  
 


 /**
     * The main method of this program. Creates the game object
     * and calls the playGame method on it.
     * @param args ignored
  */    

 
 public static void main(String[] args){
 
  A1Q4 game = new A1Q4();  

  game.playGame();
 
  
 }
 //printArray
 public static void printArray(String[] deckOfCards, int currentSize){
  if( deckOfCards == null || currentSize > deckOfCards.length) {
   System.out.println("ArrayStringsTools.printArray: wrong call");
   return ;
  }
  //sortArray(deckOfCards,currentSize);
  for(int i = 0; i < currentSize-1; i++){
   System.out.print(deckOfCards[i] + ", ");
  }
  System.out.println(deckOfCards[currentSize-1]);
 }
//sortArray
 public static void sortArray(String[] deckOfCards, int currentSize){
  if( deckOfCards == null || currentSize > deckOfCards.length) {
   System.out.println("ArrayStringsTools.sortArray: wrong call");
   return ;
  }
  java.util.Arrays.sort(deckOfCards, 0, currentSize );
 }
//shuffleArray
public static void shuffleArray(String[] deckOfCards, int currentSize){
  if( deckOfCards == null || currentSize > deckOfCards.length) {
   System.out.println("ArrayStringsTools.shuffleArray: wrong call");
   return ;
  }
  
  java.util.Random generator = new java.util.Random();

  for(int i = currentSize-1 ; i > 1 ; i--){
   swapItems(deckOfCards, i,generator.nextInt(i-1));
  }
 }

 private static void swapItems(String[] deckOfCards, int i, int j){
  String intermediate = deckOfCards[i];
  deckOfCards[i]=deckOfCards[j];
 deckOfCards[j]=intermediate;
 }
//removeItemsByIndex
 public static int removeItemByIndex(String[] deckOfCards, int currentSize, int itemToRemove){

  if( deckOfCards == null || currentSize > deckOfCards.length) {
   System.out.println("ArrayStringsTools.removeItemByIndex: wrong call");
   return currentSize;
  }
  if( itemToRemove < 0 || itemToRemove >= currentSize ) {
   System.out.println("ArrayStringsTools.removeItem: item " 
    + itemToRemove + " out of bounds. Array Unchanged.");
   return currentSize;
  }
  
  if(currentSize == 1) {
    return 0;
  }
  int i;
  for( i = itemToRemove; i < currentSize-1; i++){
   deckOfCards[i] = deckOfCards[i+1];
  }
  deckOfCards[i]= null;
  return currentSize-1;
 }
//appendItem
  public static int appendItem(String[] deckOfCards, int currentSize, String itemToAdd){

  if( deckOfCards == null || currentSize > deckOfCards.length) {
   System.out.println("ArrayStringsTools.appendItem: wrong call");
   return currentSize;
  }

  if( currentSize == deckOfCards.length) {
   System.out.println("ArrayStringsTools.appendItem: array full. Array Unchanged.");
   return currentSize;
  }
  deckOfCards[currentSize++]=itemToAdd;
  return currentSize;
 }  
}
